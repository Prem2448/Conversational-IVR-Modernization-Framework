from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
import os
from dotenv import load_dotenv
from azure.communication.identity import CommunicationIdentityClient

from database import create_table, get_pnr

load_dotenv()

ACS_CONNECTION_STRING = os.getenv("ACS_CONNECTION_STRING", "")
ACS_ENDPOINT = os.getenv("ACS_ENDPOINT", "")

app = FastAPI(title="IRCTC IVR SYSTEM")
templates = Jinja2Templates(directory="templates")

create_table()

state = {"awaiting": None}

@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.post("/acs/token")
async def get_token():
    try:
        client = CommunicationIdentityClient.from_connection_string(ACS_CONNECTION_STRING)
        user = client.create_user()
        token = client.get_token(user, scopes=["voip"])

        return {
            "token": token.token,
            "user_id": user.properties["id"],
            "endpoint": ACS_ENDPOINT
        }
    except Exception as e:
        return {"error": str(e)}

# ---------------- IVR LOGIC ----------------
@app.post("/process")
async def process(request: Request):
    data = await request.json()
    msg = data.get("message", "").lower()

    # -------- PNR --------
    if "pnr" in msg:
        return {
            "response": """PNR STATUS

PNR: 1234567890
Train: 12723 Express
From: Hyderabad → Chennai
Date: 25-Mar-2026
Status: CONFIRMED
Coach: S3
Seat: 21"""
        }

    # -------- TRAIN --------
    if "train" in msg:
        return {
            "response": """TRAIN DETAILS

Train No: 12723
Name: Telangana Express
Departure: 10:30 AM
Arrival: 06:45 PM
Platform: 2
Status: On Time"""
        }

    # -------- BOOKING --------
    if "booking" in msg:
        return {
            "response": """BOOK TICKET

Available Trains:
1. 12723 Express
2. 12627 Superfast

Seats Available:
Sleeper: Available
AC 3 Tier: Available

Fare: ₹450"""
        }

    return {"response": "Select option from below menu"}