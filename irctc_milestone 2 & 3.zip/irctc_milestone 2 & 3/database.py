import sqlite3

def connect():
    return sqlite3.connect("irctc.db")

def create_table():
    conn = connect()
    cur = conn.cursor()

    cur.execute("""
    CREATE TABLE IF NOT EXISTS pnr (
        pnr TEXT PRIMARY KEY,
        status TEXT,
        coach TEXT,
        seat TEXT
    )
    """)

    cur.execute("INSERT OR IGNORE INTO pnr VALUES ('1234567890','Confirmed','S3','21')")
    cur.execute("INSERT OR IGNORE INTO pnr VALUES ('9876543210','Waiting','S5','45')")

    conn.commit()
    conn.close()

def get_pnr(pnr):
    conn = connect()
    cur = conn.cursor()

    cur.execute("SELECT * FROM pnr WHERE pnr=?", (pnr,))
    data = cur.fetchone()

    conn.close()
    return data