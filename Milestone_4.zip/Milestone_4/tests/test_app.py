# Milestone 4 - Detailed Testing for IRCTC IVR System

from fastapi.testclient import TestClient
from main import app

client = TestClient(app)

# -------------------------------
# 1. HOME TEST
# -------------------------------
def test_home_page():
    response = client.get("/")
    assert response.status_code == 200
    print("Home page working")


# -------------------------------
# 2. PNR TESTS
# -------------------------------
def test_valid_pnr():
    response = client.post("/process", json={"message": "1234567890"})
    assert response.status_code == 200
    assert "PNR" in response.json()["response"]
    print("Valid PNR test passed")


def test_invalid_pnr():
    response = client.post("/process", json={"message": "0000000000"})
    assert response.status_code == 200
    print("Invalid PNR handled")


# -------------------------------
# 3. TRAIN TESTS
# -------------------------------
def test_train_search():
    response = client.post("/process", json={"message": "train 12723"})
    assert response.status_code == 200
    assert "Train" in response.json()["response"]
    print("Train search working")


def test_train_general():
    response = client.post("/process", json={"message": "train"})
    assert response.status_code == 200
    print("General train query working")


# -------------------------------
# 4. BOOKING TESTS
# -------------------------------
def test_booking_basic():
    response = client.post("/process", json={
        "message": "booking Hyderabad Chennai"
    })
    assert response.status_code == 200
    assert "Train" in response.json()["response"]
    print("Booking basic test passed")


def test_booking_multiple_inputs():
    steps = ["booking", "Hyderabad", "Chennai", "tomorrow"]

    for step in steps:
        response = client.post("/process", json={"message": step})
        assert response.status_code == 200

    print("Multi-step booking flow working")


# -------------------------------
# 5. VOICE SIMULATION TEST
# -------------------------------
def test_voice_simulation():
    voice_inputs = [
        "1234567890",
        "train 12723",
        "booking Hyderabad Chennai"
    ]

    for inp in voice_inputs:
        response = client.post("/process", json={"message": inp})
        assert response.status_code == 200

    print("Voice simulation test passed")


# -------------------------------
# 6. END-TO-END TEST
# -------------------------------
def test_full_system_flow():

    # Step 1: Check PNR
    res1 = client.post("/process", json={"message": "1234567890"})
    assert res1.status_code == 200

    # Step 2: Check Train
    res2 = client.post("/process", json={"message": "train 12723"})
    assert res2.status_code == 200

    # Step 3: Booking
    res3 = client.post("/process", json={"message": "booking Hyderabad Chennai"})
    assert res3.status_code == 200

    print("End-to-End flow successful")


# -------------------------------
# 7. ERROR HANDLING
# -------------------------------
def test_random_input():
    response = client.post("/process", json={"message": "hello random text"})
    assert response.status_code == 200
    print("Random input handled")


def test_empty_input():
    response = client.post("/process", json={"message": ""})
    assert response.status_code == 200
    print("Empty input handled")


# -------------------------------
# 8. PERFORMANCE TEST (LIGHT)
# -------------------------------
def test_multiple_requests():
    for i in range(10):
        response = client.post("/process", json={"message": "train"})
        assert response.status_code == 200

    print("Multiple request test passed")