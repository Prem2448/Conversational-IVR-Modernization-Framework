# database.py (dummy database for testing)

def create_table():
    return True

def get_pnr(pnr):
    data = {
        "1234567890": {
            "status": "Confirmed",
            "coach": "S3",
            "seat": "21"
        }
    }
    return data.get(pnr, {"status": "Waiting"})